﻿namespace RemoteControl.Agent.Models
{
    public class ResponseDto
    {
        // Gán giá trị mặc định để tránh lỗi CS8618 (Non-nullable property)
        public string AgentId { get; set; } = string.Empty;
        public string DataType { get; set; } = string.Empty;
        public object? Data { get; set; } // Cho phép null bằng dấu ?
    }

    public class CommandDto
    {
        public string CommandType { get; set; } = string.Empty;
        public string Payload { get; set; } = string.Empty;
    }
}