﻿using System.Diagnostics;

namespace RemoteControl.Agent.Services.System
{
    public class ProcessHandler
    {
        // 1. LIỆT KÊ TẤT CẢ PROCESS (Giống tab Details trong Task Manager)
        public List<string> GetProcesses()
        {
            var list = new List<string>();
            var processes = Process.GetProcesses();
            foreach (var p in processes)
            {
                try { list.Add($"{p.Id}|{p.ProcessName}|{p.WorkingSet64 / 1024} KB"); }
                catch { }
            }
            return list;
        }

        // 2. LIỆT KÊ CÁC APP ĐANG CHẠY (Giống tab Processes trong Task Manager - chỉ hiện app có cửa sổ)
        public List<string> GetRunningApps()
        {
            var list = new List<string>();
            var processes = Process.GetProcesses();
            foreach (var p in processes)
            {
                // Chỉ lấy những process có tiêu đề cửa sổ (MainWindowTitle)
                if (!string.IsNullOrEmpty(p.MainWindowTitle))
                {
                    list.Add($"{p.Id}|{p.ProcessName}|{p.MainWindowTitle}");
                }
            }
            return list;
        }

        // 3. START APP (Mở ứng dụng mới từ đường dẫn hoặc tên)
        public string StartApp(string appNameOrPath)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = appNameOrPath,
                    UseShellExecute = true // Quan trọng để mở được file exe hoặc url
                });
                return "OK";
            }
            catch (Exception ex)
            {
                return $"Error: {ex.Message}";
            }
        }

        // 4. STOP APP/PROCESS (Tắt dựa trên ID)
        public void KillProcess(int pid)
        {
            try
            {
                var p = Process.GetProcessById(pid);
                p.Kill();
            }
            catch (Exception) { }
        }
    }
}