﻿using System.Diagnostics;

namespace RemoteControl.Agent.Services.System
{
    public class PowerHandler
    {
        public void Shutdown()
        {
            StartProcess("shutdown", "/s /t 0");
        }

        public void Restart()
        {
            StartProcess("shutdown", "/r /t 0");
        }

        private void StartProcess(string fileName, string arguments)
        {
            try
            {
                var psi = new ProcessStartInfo(fileName, arguments)
                {
                    CreateNoWindow = true,
                    UseShellExecute = false
                };
                Process.Start(psi);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Lỗi nguồn: {ex.Message}");
            }
        }
    }
}