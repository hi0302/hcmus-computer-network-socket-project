﻿using System.Drawing; // Cần cài System.Drawing.Common
using System.Drawing.Imaging;
using RemoteControl.Agent.Native;

namespace RemoteControl.Agent.Services.Media
{
    public class ScreenCapturer
    {
        public byte[] TakeScreenshot()
        {
            try
            {
                // Lấy độ phân giải màn hình từ NativeMethods (hoặc dùng SystemParameters nếu là WPF/Forms)
                int width = NativeMethods.GetSystemMetrics(NativeMethods.SM_CXSCREEN);
                int height = NativeMethods.GetSystemMetrics(NativeMethods.SM_CYSCREEN);

                using (Bitmap bmp = new Bitmap(width, height))
                {
                    using (Graphics g = Graphics.FromImage(bmp))
                    {
                        g.CopyFromScreen(0, 0, 0, 0, bmp.Size);
                    }

                    using (MemoryStream ms = new MemoryStream())
                    {
                        // Lưu ảnh dạng JPEG để giảm dung lượng khi gửi qua mạng
                        bmp.Save(ms, ImageFormat.Jpeg);
                        return ms.ToArray();
                    }
                }
            }
            catch (Exception)
            {
                return Array.Empty<byte>();
            }
        }
    }
}